/*
 * Serve JSON to our AngularJS client
 */

exports.name = function (req, res) {
    res.json({
        name: 'Node js and Angular js with mssql database'
    });
};

/*
 * Connect to mssql database 
 */


exports.Result = function (req, res) {
    var sql = require('mssql');
    
    var config = {
        user: 'ADISOFT10-PC',
        password: 'adisoft@5455',
        server: 'ADISOFT\\ADISQL2008',
        database: 'IMS1.0',
        options: { encrypt: false }
    };
    
    var connection = new sql.Connection(config);
    
    connection.connect(function (err) {
        if (err) { res.status(500).send(err); return; }
        
        var request = new sql.Request(connection);
      
        var sqlString = 'SELECT COUNT(*) CT from System.Day';
        request.query(sqlString, function (err, rs) {
            connection.close();
            
            if (err) { res.status(500).send(err); return; }
            
            var count = rs[0].CT;
            res.json({
                Result: count
            });
        });
    });
};
