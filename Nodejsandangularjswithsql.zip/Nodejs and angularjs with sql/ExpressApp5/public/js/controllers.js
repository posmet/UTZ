'use strict';

/* Controllers */

angular.module('myApp.controllers', []).
  controller('AppCtrl', function ($scope, $http) {
    
    $http({
        method: 'GET',
        url: '/api/name'
    }).
    success(function (data, status, headers, config) {
        $scope.name = data.name;
    }).
    error(function (data, status, headers, config) {
        $scope.name = 'Error!';
    });

}).
 
   controller('MyCtrl1', function ($scope, $http) {
    
    $http({
        method: 'GET',
        url: '/api/Result'
    }).
    success(function (data, status, headers, config) {
        $scope.Result = data.Result;
    }).
    error(function (data, status, headers, config) {
        $scope.Result = 'Error!';
    });

}).
 
//    controller('MyCtrl1', function ($scope, $http) {
        
//        $scope.widget = { title: 'abc' };


//}).
controller('MyCtrl2', function ($scope) {
    // write Ctrl here

});
